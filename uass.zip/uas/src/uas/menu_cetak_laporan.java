/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package uas;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.Connection;

/**
 *
 * @author Nabila
 */
public class menu_cetak_laporan extends javax.swing.JFrame {
    private javax.swing.JTextField txtkode;
    private javax.swing.JTextField txtnama;
    private javax.swing.JComboBox<String> cbjenis;
    private javax.swing.JTextField txtjumlah;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtpajak;
    private javax.swing.JTextField txttotal;
    Object btn_input;
    Object btn_delete;
    Object btn_update;
    Object btn_transaksi;
    /**
     * Creates new form menu_cetak_laporan
     */
    public menu_cetak_laporan() {
        initComponents();
        TampilkanData();
    }
    
    private void cetak() {
        setTitle("Menu Cetak Laporan");
        setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        
        jPanel1 = new javax.swing.JPanel();
        jPanel1.setLayout(new java.awt.BorderLayout());

        jLabel1 = new javax.swing.JLabel("Laporan");
        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jLabel1, java.awt.BorderLayout.NORTH);
        
        tabel_laporan = new javax.swing.JTable();
        tabel_laporan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {
                "Kode", "Nama", "Jenis", "Harga", "Jumlah", "Pajak", "Total"
            }
        ));
        tabel_laporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_laporanMouseClicked(evt);
            }
        });
        
        jScrollPane1 = new javax.swing.JScrollPane(tabel_laporan);
        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        
        logout = new javax.swing.JButton("Cetak");
        jPanel1.add(logout, java.awt.BorderLayout.SOUTH);
        
        // Inisialisasi komponen input
        txtkode = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        cbjenis = new javax.swing.JComboBox<>();
        txtjumlah = new javax.swing.JTextField();
        txtharga = new javax.swing.JTextField();
        txtpajak = new javax.swing.JTextField();
        txttotal = new javax.swing.JTextField();
        
        javax.swing.JPanel inputPanel = new javax.swing.JPanel();
        inputPanel.setLayout(new java.awt.GridLayout(7, 2));
        inputPanel.add(new javax.swing.JLabel("Kode:"));
        inputPanel.add(txtkode);
        inputPanel.add(new javax.swing.JLabel("Nama:"));
        inputPanel.add(txtnama);
        inputPanel.add(new javax.swing.JLabel("Jenis:"));
        inputPanel.add(cbjenis);
        inputPanel.add(new javax.swing.JLabel("Jumlah:"));
        inputPanel.add(txtjumlah);
        inputPanel.add(new javax.swing.JLabel("Harga:"));
        inputPanel.add(txtharga);
        inputPanel.add(new javax.swing.JLabel("Pajak:"));
        inputPanel.add(txtpajak);
        inputPanel.add(new javax.swing.JLabel("Total:"));
        inputPanel.add(txttotal);
        
        jPanel1.add(inputPanel, java.awt.BorderLayout.WEST);

        logout = new javax.swing.JButton("Logout");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        getContentPane().add(jPanel1);
    }

    private void TampilkanData() {
        DefaultTableModel model = (DefaultTableModel) tabel_laporan.getModel();
        model.setRowCount(0); // Clear existing data

        try {
            koneksi e = new koneksi();
            e.connect();
            Connection conn = e.getCon();
            String SQL = "SELECT * FROM transaksi";
            java.sql.Statement stmt = conn.createStatement();
            java.sql.ResultSet res = stmt.executeQuery(SQL);
            
            while (res.next()) {
                model.addRow(new Object[]{
                    res.getString("kode"),
                    res.getString("nama"),
                    res.getString("jenis"),
                    res.getString("harga"),
                    res.getString("jumlah"),
                    res.getString("pajak"),
                    res.getString("total")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Gagal Menampilkan Data: " + ex.getMessage());
        }}
    

   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_laporan = new javax.swing.JTable();
        logout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setForeground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("LAPORAN PENJUALAN KENDARAAN ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        tabel_laporan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel_laporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_laporanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel_laporan);

        logout.setText("Logout");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(logout)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(106, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(logout)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabel_laporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_laporanMouseClicked
             
        int row = tabel_laporan.getSelectedRow();
        if (row != -1) {
            // Ambil model dari tabel
            TableModel model = tabel_laporan.getModel();

            // Ambil data dari baris yang diklik
            String kode = model.getValueAt(row, 0).toString();
            String nama = model.getValueAt(row, 1).toString();
            String jenis = model.getValueAt(row, 2).toString();
            String harga = model.getValueAt(row, 3).toString();
            String jumlah = model.getValueAt(row, 4).toString();
            String pajak = model.getValueAt(row, 5).toString();
            String total = model.getValueAt(row, 6).toString();

        // Tampilkan data dalam komponen GUI yang sesuai
        txtkode.setText(kode);
        txtnama.setText(nama);
        cbjenis.setSelectedItem(jenis); // Pastikan cbjenis sudah diinisialisasi dengan item yang sesuai
        txtharga.setText(harga);
        txtjumlah.setText(jumlah);
        txtpajak.setText(pajak);
        txttotal.setText(total);
        }
    }//GEN-LAST:event_tabel_laporanMouseClicked

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        login l = new login();
        l.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_logoutActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new menu_cetak_laporan().setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    private javax.swing.JTable tabel_laporan;
    // End of variables declaration//GEN-END:variables
}

